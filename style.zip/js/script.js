let currentDate = new Date();
let currentView = 'month';

// أسماء الأشهر الميلادية
const monthNames = [
    'يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'
];

// أسماء الأشهر البعثية (يمكن تعديلها حسب نظامك الفعلي)
const baathMonths = [
    "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
];

// تحويل: السنة البعثية = السنة الميلادية - 609
function gregorianToBaath(gregorianYear, gregorianMonth) {
    // عدّل الرقم 609 إذا عندك مرجع بداية مختلف لتقويم البعثة!
    const baathYear = gregorianYear - 609;
    const baathMonth = gregorianMonth % 12;
    return {
        year: baathYear,
        month: baathMonth
    };
}

document.addEventListener('DOMContentLoaded', () => {
    renderCalendar();
});

function renderCalendar() {
    updateYearDisplay();

    if (currentView === 'month') {
        renderMonthView();
        document.getElementById('monthView').style.display = 'block';
        document.getElementById('yearView').style.display = 'none';
    } else {
        renderYearView();
        document.getElementById('monthView').style.display = 'none';
        document.getElementById('yearView').style.display = 'grid';
    }
}

function setView(view) {
    currentView = view;
    document.querySelectorAll('.view-btn').forEach(btn => btn.classList.remove('active'));
    if (view==='month') document.querySelector('.view-btn:nth-child(1)').classList.add('active');
    else document.querySelector('.view-btn:nth-child(2)').classList.add('active');
    renderCalendar();
}

function updateYearDisplay() {
    let y = currentDate.getFullYear();
    let baathYear = y - 609;
    document.getElementById('gregorianYear').textContent = y;
    document.getElementById('baathYear').textContent = baathYear;
}

function renderMonthView() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = new Date(year, month+1, 0).getDate();

    // تحويل وإظهار الشهر والسنة البعثية مع الميلادية
    const baath = gregorianToBaath(year, month);
    const baathMonthName = baathMonths[baath.month];
    const baathYear = baath.year;

    document.getElementById('monthHeader').innerHTML =
        `${monthNames[month]} ${year} - ${baathMonthName} ${baathYear} للبعثة`;

    let grid = document.getElementById('calendarGrid');
    grid.innerHTML = '';
    let firstDay = new Date(year, month, 1).getDay();
    let firstDayOnGrid = (firstDay + 6) % 7;

    for (let i=0; i<firstDayOnGrid; i++) {
        let cell = document.createElement('div');
        cell.className = 'calendar-day other-month';
        grid.appendChild(cell);
    }

    for (let day=1; day <= daysInMonth; day++) {
        let date = new Date(year, month, day);
        let cell = document.createElement('div');
        cell.className = 'calendar-day';
        if (date.getDay() === 5 || date.getDay() === 6) cell.classList.add('weekend');
        let today = new Date();
        if (
            date.getFullYear() === today.getFullYear() &&
            date.getMonth() === today.getMonth() &&
            date.getDate() === today.getDate()
        ) cell.classList.add('today');
        cell.innerHTML = `
            <div class="baath-date">${day}</div>
            <div class="gregorian-info">
                <div class="gregorian-day">${day}</div>
                <div class="gregorian-month">${monthNames[month].substr(0,3)}</div>
            </div>
        `;
        grid.appendChild(cell);
    }
}

function renderYearView() {
    const yearView = document.getElementById('yearView');
    yearView.innerHTML = '';
    const year = currentDate.getFullYear();
    const weekdaysShort = ['أحد', 'إثن', 'ثلث', 'أرب', 'خمس', 'جمع', 'سبت'];

    for (let month = 0; month < 12; month++) {
        const baath = gregorianToBaath(year, month);
        const baathMonthName = baathMonths[baath.month];
        const baathYear = baath.year;

        const monthCard = document.createElement('div');
        monthCard.className = 'mini-calendar';

        // <--- هنا عنوان الشهر بنظامين
        const header = document.createElement('div');
        header.className = 'mini-month-header';
        header.innerText =
            `${monthNames[month]} ${year} - ${baathMonthName} ${baathYear} للبعثة`;
        monthCard.appendChild(header);

        const daysHeader = document.createElement('div');
        daysHeader.className = 'mini-days-row';
        weekdaysShort.forEach(day => {
            const dayCell = document.createElement('div');
            dayCell.className = 'mini-day-header';
            dayCell.innerText = day;
            daysHeader.appendChild(dayCell);
        });
        monthCard.appendChild(daysHeader);

        const daysGrid = document.createElement('div');
        daysGrid.className = 'mini-days-grid';

        const firstDay = new Date(year, month, 1);
        let start = (firstDay.getDay() + 6) % 7;
        let daysInMonth = new Date(year, month+1, 0).getDate();
        for (let i = 0; i < start; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'mini-day empty';
            daysGrid.appendChild(emptyCell);
        }
        for (let day = 1; day <= daysInMonth; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'mini-day';
            dayCell.innerText = day;
            daysGrid.appendChild(dayCell);
        }
        monthCard.appendChild(daysGrid);
        yearView.appendChild(monthCard);
    }
}

function previousYear() {
    currentDate.setFullYear(currentDate.getFullYear() - 1);
    renderCalendar();
}
function nextYear() {
    currentDate.setFullYear(currentDate.getFullYear() + 1);
    renderCalendar();
}
function goToToday() {
    currentDate = new Date();
    renderCalendar();
}
function searchDate() {
    const baathYear = parseInt(document.getElementById('searchBaath').value,10);
    const gregorianYear = parseInt(document.getElementById('searchGregorian').value,10);
    if (!isNaN(baathYear)) {
        currentDate.setFullYear(baathYear+609); renderCalendar(); return;
    }
    if (!isNaN(gregorianYear)) {
        currentDate.setFullYear(gregorianYear); renderCalendar(); return;
    }
    alert("أدخل سنة صحيحة بعثية أو ميلادية للبحث!");
}

